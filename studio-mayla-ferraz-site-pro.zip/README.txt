# Studio Mayla Ferraz — Site PRO

Recursos:
- Agendamento online via WhatsApp (mensagem com serviço/data/hora)
- Mapa do Google Maps incorporado
- SEO pronto (title/description, Open Graph/Twitter)
- JSON-LD LocalBusiness
- Favicon, robots.txt, sitemap.xml, manifest.json
- Analytics: troque `GA_ID` (no `<head>`) pelo seu Measurement ID do GA4

Publicação rápida:
1) Netlify Drop (arraste a pasta/ZIP) ou Vercel
2) Depois configure seu domínio para apontar ao projeto
