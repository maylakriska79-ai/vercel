
document.getElementById('year').textContent = new Date().getFullYear();
const WHATS_NUMBER = '5546999283511';
function wurl(message) {
  return `https://wa.me/${WHATS_NUMBER}?text=${encodeURIComponent(message)}`;
}
const defaultMsg = 'Olá! Vim pelo site e quero saber mais 🙂';
['whats-top','whats-hero','whats-s1','whats-s2','whats-s3','whats-s4','whats-s5','whats-s6','whats-final'].forEach(id=>{
  const el = document.getElementById(id);
  if(!el) return;
  const svc = el.getAttribute('data-svc');
  el.href = wurl(svc ? `Olá! Quero reservar *${svc}*.` : defaultMsg);
});
// Booking form -> WhatsApp
const btn = document.getElementById('book-btn');
if(btn){
  btn.addEventListener('click', ()=>{
    const svc = document.getElementById('svc').value;
    const name = document.getElementById('name').value || 'Cliente';
    const date = document.getElementById('date').value;
    const time = document.getElementById('time').value;
    const when = (date && time) ? `${date.split('-').reverse().join('/')} às ${time}` : 'próxima disponibilidade';
    const msg = `Olá, sou ${name}! Quero agendar *${svc}* para ${when}.`;
    window.open(wurl(msg), '_blank');
  });
}
